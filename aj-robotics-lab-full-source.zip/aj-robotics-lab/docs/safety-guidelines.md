# Safety Guidelines

AJ Robotics Lab is an educational project. These guidelines do not replace manufacturer instructions, formal training or applicable law.

1. Read the datasheet and board documentation before connecting components.
2. Check voltage, current, polarity and power ratings.
3. Disconnect power before changing circuit wiring.
4. Use current-limiting resistors and suitable drivers for motors and other loads.
5. Never power motors or servos directly from GPIO pins.
6. Use batteries and chargers only as specified by their manufacturers; protect against short circuits.
7. Keep liquids, conductive debris and flammable materials away from powered electronics.
8. Do not experiment with mains electricity unless properly qualified and equipped.
9. Simulate first where possible; test with moving parts removed or secured.
10. Stop immediately if components become unusually hot, swell, smoke or smell unusual.
