# Contribution Guidelines

Contributions should help people learn safely and accurately.

## Before submitting
- Explain the learning objective and intended audience.
- Use clear, respectful language.
- Test code where practical and state the exact board and software versions.
- Include a wiring diagram or clear connection list when relevant.
- Cite datasheets, documentation and third-party material.
- State known limitations and safety considerations.
- Do not include credentials, private data or copyrighted material without permission.

## Suggested project format
1. Overview
2. Required components
3. Wiring or architecture
4. Code and dependencies
5. Setup instructions
6. Testing and results
7. Troubleshooting
8. Safety notes
9. References
