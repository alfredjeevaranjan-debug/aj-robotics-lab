# Research and Publication Policy

- Distinguish original experiments from summaries of other people's work.
- Cite reliable sources and provide publication or access dates where appropriate.
- Do not invent results, measurements, authorship or qualifications.
- Explain methods, equipment, conditions and limitations.
- Correct mistakes transparently.
- Respect privacy, copyright, licences and research ethics.
- Label untested concepts, simulations and prototypes accurately.
- Do not present educational content as professional engineering, medical or safety advice.
