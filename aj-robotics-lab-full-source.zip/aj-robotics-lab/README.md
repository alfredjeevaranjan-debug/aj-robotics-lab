# AJ Robotics Lab

**Tagline:** Build. Learn. Experiment. Innovate.

AJ Robotics Lab is an independent educational technology website covering robotics, Arduino, ESP32, electronics, automation, artificial intelligence and engineering projects.

## Website sections
- Home and About
- Robotics
- Arduino Laboratory
- ESP32 Laboratory
- AI Research
- Electronics and Automation
- Projects and Tutorials
- Research and Publications
- Technology News
- Resources and Contact

## Repository structure
```text
aj-robotics-lab/
├── index.html
├── about.html
├── robotics.html
├── arduino.html
├── esp32.html
├── ai-research.html
├── electronics.html
├── automation.html
├── projects.html
├── tutorials.html
├── research.html
├── news.html
├── resources.html
├── contact.html
├── css/style.css
├── js/script.js
├── images/README.md
├── projects/
├── docs/
├── README.md
├── LICENSE
└── .gitignore
```

## Run locally
Open `index.html` in a modern browser. For a local development server, use the Live Server extension in Visual Studio Code or another static-file server.

## Publish with GitHub Pages
1. Create a public GitHub repository named `aj-robotics-lab`.
2. Upload the contents of this folder to the repository root. `index.html` must be at the root, not inside another folder.
3. Open repository **Settings → Pages**.
4. Under **Build and deployment**, select **Deploy from a branch**.
5. Select branch `main` and folder `/ (root)`, then save.
6. Wait for the deployment to finish. Your address will usually be `https://YOUR-USERNAME.github.io/aj-robotics-lab/`.

## Important limitations
This is a static HTML, CSS and JavaScript website. The contact page is informational only: it does not send messages. There is no database, login, user registration, admin dashboard or content management system. Those features require a secure backend or a suitable third-party service.

## Safety and accuracy
Use official board documentation and component datasheets. Do not publish passwords, API keys or private Wi-Fi credentials. Check all wiring and power requirements before building.
