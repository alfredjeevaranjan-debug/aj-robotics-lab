# Images folder

Place your own properly licensed images in this folder.

Recommendations:
- Use descriptive filenames such as `arduino-led-circuit.jpg`.
- Add meaningful `alt` text when using images in HTML.
- Record the creator, source and licence for third-party images.
- Do not upload images you do not have permission to use.
