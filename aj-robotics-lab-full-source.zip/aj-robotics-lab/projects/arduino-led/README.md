# Arduino LED and Button — Starter Project

## Objective
Learn a basic digital output and digital input using an Arduino-compatible board.

## Example components
- Arduino-compatible development board
- LED and suitable current-limiting resistor
- Push button
- Breadboard and jumper wires
- USB cable

## Build notes
Check your exact board pinout and LED polarity. Use a current-limiting resistor selected for the LED and board. Disconnect USB power before changing wiring.

## Code
Add your tested Arduino sketch here as `arduino-led.ino`.

## Testing record
Document the board model, wiring, code version, expected behaviour, observed behaviour and any faults.

## Safety
This is a low-voltage educational project. Do not connect GPIO pins directly to mains voltage or loads that exceed board ratings.
