# ESP32 Mini-Drone Concept — Planning and Simulation

## Objective
Document a learning concept for understanding control systems, servos, sensors and simulation.

## Scope
This repository note is for research and simulation planning. It is not a verified flight controller, aircraft design or flight-ready build guide.

## Research checklist
- Identify the exact ESP32 board and servo specifications.
- Calculate power requirements using component datasheets.
- Do not power multiple servos from an ESP32 GPIO pin or an unsuitable board regulator.
- Plan a correctly rated external supply and a common ground where the circuit design requires it.
- Add suitable protection and an emergency stop concept.
- Simulate and test control logic without propellers before considering any physical prototype.

## Documentation
Record the simulator, wiring diagram, code version, test conditions, results and limitations.

## Safety
Never test near people or animals. Do not attach propellers during initial electronics tests. Follow applicable UK aviation and model aircraft rules before any real flight.
