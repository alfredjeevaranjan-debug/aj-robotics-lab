# ESP32 Local Web Server — Starter Project

## Objective
Learn how an ESP32 can host a simple page on a local Wi-Fi network.

## Example components
- ESP32 development board
- USB data cable
- Computer and local Wi-Fi network

## Important privacy note
Never publish Wi-Fi names, passwords, private IP details or access tokens in a public repository. Use local configuration files excluded by `.gitignore`, and provide a safe example configuration instead.

## Development
Record your board variant, framework, library versions and tested browser/device.

## Testing
Test only on a network you own or are authorised to use. Do not expose an experimental server to the public internet without appropriate security review.
